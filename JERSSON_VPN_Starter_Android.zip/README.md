# JERSSON VPN — prototipo inicial

Este proyecto es un **prototipo de interfaz Android compilable**, no una VPN funcional todavía.

## Estado
- Interfaz Android oscura y navegación básica: incluida.
- Selector de ubicaciones de demostración: incluido; no representa servidores disponibles.
- Motor OpenVPN / túnel Android VpnService: pendiente.
- Mapa real con servidores en vivo: pendiente.
- Filtrado DNS de anuncios y rastreadores: pendiente.
- Kill switch y pruebas de fugas: pendientes.

**No uses esta versión para proteger tráfico ni para operaciones sensibles.** No muestra una conexión falsa ni afirma que el filtrado esté funcionando.

## Compilar desde el móvil con GitHub Actions
1. Crea un repositorio nuevo en GitHub desde el navegador o la app.
2. Sube el contenido de este ZIP conservando las carpetas y archivos.
3. Abre la pestaña **Actions** del repositorio.
4. Ejecuta **Build JERSSON VPN APK** con **Run workflow**.
5. Cuando termine, abre la ejecución y descarga el artefacto `JERSSON-VPN-debug`.
6. Descomprime el artefacto y encontrarás `app-debug.apk`.

La compilación se realiza en los servidores de GitHub; no necesitas una PC. Para instalar el APK, Android puede pedir permiso para instalar aplicaciones desde esa fuente.

## Próximo trabajo necesario
Antes de distribuir una VPN real hay que integrar un motor OpenVPN mantenido, obtener una fuente de servidores confiable y validar certificados, rutas, DNS, reconexión y fugas. Los servidores VPN públicos gratuitos pueden ser inestables y no deben tratarse como privados ni anónimos.
