package com.jerssonvpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1C1E26)
private val Red = Color(0xFFCE2945)
private val Muted = Color(0xFF9A9DAA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JerssonApp() }
    }
}

@Composable
fun JerssonApp() {
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf("Automático") }
    var adBlock by remember { mutableStateOf(true) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Shield, null) }, label = { Text("VPN") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Public, null) }, label = { Text("Ubicaciones") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Ajustes") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, null, tint = Red, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("JERSSON VPN", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("PRIVACY • SECURITY • FREEDOM", fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
                    }
                }
                Spacer(Modifier.height(28.dp))
                when (tab) {
                    0 -> HomeScreen(selected)
                    1 -> LocationsScreen(selected) { selected = it }
                    else -> SettingsScreen(adBlock) { adBlock = it }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(selected: String) {
    Spacer(Modifier.height(18.dp))
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(170.dp).background(Color(0xFF321923), CircleShape).padding(12.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().background(Color(0xFF20232D), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PowerSettingsNew, null, tint = Red, modifier = Modifier.size(68.dp))
            }
        }
    }
    Spacer(Modifier.height(20.dp))
    Text("AÚN NO CONECTADO", modifier = Modifier.fillMaxWidth(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    Text("Esta versión es una vista inicial. No crea un túnel VPN todavía.", modifier = Modifier.fillMaxWidth(), color = Muted, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    Spacer(Modifier.height(28.dp))
    InfoCard("Ubicación seleccionada", selected, Icons.Default.Public)
    Spacer(Modifier.height(12.dp))
    InfoCard("Estado de protección", "Interfaz preparada · motor VPN pendiente", Icons.Default.Security)
    Spacer(Modifier.height(18.dp))
    Text("Importante: no introduzcas contraseñas ni datos bancarios en esta versión.", color = Color(0xFFFFC66D), fontSize = 12.sp)
}

@Composable
fun InfoCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Red, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
fun LocationsScreen(selected: String, onSelect: (String) -> Unit) {
    Text("UBICACIONES", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Text("Lista de ejemplo; aún no son servidores verificados.", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(14.dp))
    val places = listOf("Automático", "Estados Unidos", "Canadá", "Alemania", "Francia", "Países Bajos", "Japón", "Singapur")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(places) { place ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).clickable { onSelect(place) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, null, tint = Red)
                Spacer(Modifier.width(12.dp))
                Text(place, color = Color.White, modifier = Modifier.weight(1f))
                if (selected == place) Icon(Icons.Default.CheckCircle, null, tint = Red)
            }
        }
    }
}

@Composable
fun SettingsScreen(adBlock: Boolean, onAdBlock: (Boolean) -> Unit) {
    Text("PRIVACIDAD Y SEGURIDAD", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Filtro DNS de anuncios", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("Preferencia visual; el filtrado real aún no está implementado.", color = Muted, fontSize = 11.sp)
        }
        Switch(checked = adBlock, onCheckedChange = onAdBlock)
    }
    Spacer(Modifier.height(12.dp))
    InfoCard("Motor VPN", "Pendiente de integrar OpenVPN", Icons.Default.VpnLock)
    Spacer(Modifier.height(12.dp))
    InfoCard("Mapa", "Pendiente de integrar mapa y catálogo en vivo", Icons.Default.Map)
}
