# JERSSON VPN — versión 0.2.0 (interfaz premium)

Aplicación Android de código abierto en desarrollo, con identidad visual negro/rojo premium.

## Estado real de esta versión
- Interfaz renovada con logotipo de escudo JERSSON.
- Navegación Inicio / Servidores / Ajustes.
- Catálogo de países únicamente ilustrativo: todavía no muestra servidores en vivo.
- Motor OpenVPN y túnel Android: pendiente.
- Filtro DNS, protección contra fugas y Kill Switch: pendientes.

**Importante:** esta versión NO es una VPN funcional y no protege el tráfico del teléfono. No la uses para actividades sensibles ni como sustituto de una VPN operativa.

## Compilar desde un teléfono con GitHub Actions
1. Sube el contenido de este ZIP al repositorio GitHub, conservando las carpetas.
2. Abre la pestaña **Actions**.
3. Ejecuta **Build JERSSON VPN APK** con **Run workflow** (o espera al push a `main`).
4. Abre la ejecución completada y descarga el artefacto `JERSSON-VPN-debug`.
5. Descomprime el artefacto para obtener `app-debug.apk`.

El flujo usa Java 17 y Gradle 8.9; la compilación ocurre en GitHub, no en el teléfono.

## Próxima etapa: VPN gratuita real
Evaluar una fuente pública de relays (por ejemplo, VPN Gate), consultar disponibilidad y obtener perfiles OpenVPN. Antes de conectar usuarios se debe revisar la licencia y condiciones de uso, validar los perfiles y certificados, integrar un motor OpenVPN mantenido, implementar el servicio VPN de Android y probar DNS, rutas, reconexión y fugas.

Los servidores públicos gratuitos son operados por terceros: pueden ser lentos, desaparecer y no ofrecen garantías de privacidad. La aplicación deberá mostrar claramente quién opera cada servidor y sus límites.
