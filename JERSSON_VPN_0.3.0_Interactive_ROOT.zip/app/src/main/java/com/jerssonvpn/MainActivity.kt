package com.jerssonvpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF151821)
private val PanelLight = Color(0xFF1D222D)
private val Red = Color(0xFFE32645)
private val RedDark = Color(0xFF78182B)
private val Muted = Color(0xFF9CA3B2)
private val White = Color(0xFFF5F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JerssonApp() }
    }
}

@Composable
fun JerssonApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf("Automático") }
    var notifications by remember { mutableStateOf(true) }
    var connectionInfo by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF10131A), contentColor = White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Shield, null) }, label = { Text("Inicio") }, colors = navColors())
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Public, null) }, label = { Text("Servidores") }, colors = navColors())
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Ajustes") }, colors = navColors())
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding)) {
                Header()
                when (tab) {
                    0 -> HomeScreen(selected) { connectionInfo = true }
                    1 -> LocationsScreen(selected) { selected = it }
                    else -> SettingsScreen(notifications) { notifications = it }
                }
            }
        }
        if (connectionInfo) {
            AlertDialog(
                onDismissRequest = { connectionInfo = false },
                containerColor = Panel,
                title = { Text("Conexión todavía no disponible", color = White) },
                text = { Text("La interfaz y la selección de servidor ya funcionan, pero esta versión aún no incluye el motor OpenVPN ni perfiles de servidores verificados. No se ha iniciado ningún túnel y tu tráfico no está protegido por JERSSON VPN.", color = Muted) },
                confirmButton = {
                    TextButton(onClick = { connectionInfo = false }) { Text("Entendido", color = Red) }
                }
            )
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Red,
    selectedTextColor = White,
    indicatorColor = Color(0xFF38202A),
    unselectedIconColor = Muted,
    unselectedTextColor = Muted
)

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.jersson_logo), contentDescription = "Escudo JERSSON VPN", modifier = Modifier.size(54.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("JERSSON VPN", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("PRIVACY  •  SECURITY  •  FREEDOM", color = Muted, fontSize = 8.sp, letterSpacing = 1.2.sp)
        }
        Box(Modifier.size(9.dp).clip(CircleShape).background(Red))
    }
}

@Composable
fun HomeScreen(selected: String, onConnectClick: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(10.dp))
        Text("TU PRIVACIDAD, NUESTRA PRIORIDAD", color = Muted, fontSize = 10.sp, letterSpacing = 1.3.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Box(
            Modifier.size(220.dp).background(Brush.radialGradient(listOf(Color(0xFF49202D), Color(0xFF1B1119), Bg)), CircleShape).padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(painterResource(R.drawable.jersson_logo), contentDescription = "Logotipo JERSSON VPN", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
        Spacer(Modifier.height(12.dp))
        Text("DESCONECTADO", color = White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
        Text("Motor VPN pendiente de integración", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onConnectClick,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = White),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.PowerSettingsNew, contentDescription = null)
            Spacer(Modifier.width(9.dp))
            Text("CONECTAR", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Lock, null, tint = Red, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("ESTADO DEL PROYECTO", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                Text("Interfaz lista · motor en desarrollo", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            Surface(color = Color(0xFF39232A), shape = RoundedCornerShape(20.dp)) {
                Text("PRE-ALFA", color = Color(0xFFFF8295), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        InfoCard("Servidor elegido", selected, Icons.Default.Public, "Selección de catálogo; aún sin conexión")
        Spacer(Modifier.height(12.dp))
        InfoCard("Protección", "Todavía no activa", Icons.Default.Security, "No enruta ni protege el tráfico del teléfono")
        Spacer(Modifier.weight(1f))
        Text("VERSIÓN 0.3.0  •  MOTOR VPN EN DESARROLLO", color = Color(0xFF646B79), fontSize = 9.sp, letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 12.dp))
    }
}

@Composable
fun InfoCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, detail: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF30202A)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Red, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Muted, fontSize = 10.sp)
            Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(detail, color = Muted, fontSize = 9.sp)
        }
    }
}

private data class ServerOption(val country: String, val subtitle: String, val flag: String)

@Composable
fun LocationsScreen(selected: String, onSelect: (String) -> Unit) {
    val places = listOf(
        ServerOption("Automático", "Elegir el servidor disponible", "◎"),
        ServerOption("Estados Unidos", "Catálogo previsto · disponibilidad pendiente", "🇺🇸"),
        ServerOption("Canadá", "Catálogo previsto · disponibilidad pendiente", "🇨🇦"),
        ServerOption("Alemania", "Catálogo previsto · disponibilidad pendiente", "🇩🇪"),
        ServerOption("Francia", "Catálogo previsto · disponibilidad pendiente", "🇫🇷"),
        ServerOption("Países Bajos", "Catálogo previsto · disponibilidad pendiente", "🇳🇱"),
        ServerOption("Japón", "Catálogo previsto · disponibilidad pendiente", "🇯🇵"),
        ServerOption("Singapur", "Catálogo previsto · disponibilidad pendiente", "🇸🇬")
    )
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text("SERVIDORES GRATUITOS", color = White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
        Text("Selecciona una ubicación del catálogo. La conexión real se habilitará al integrar perfiles y motor VPN.", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(14.dp))
        Surface(color = Color(0xFF30202A), shape = RoundedCornerShape(12.dp)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = Color(0xFFFF8295), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("La selección se guarda en la pantalla; todavía no hay servidores conectables.", color = Color(0xFFFFC3CC), fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(places) { place ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).clickable { onSelect(place.country) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(place.flag, fontSize = 23.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(place.country, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(place.subtitle, color = Muted, fontSize = 9.sp)
                    }
                    if (selected == place.country) Icon(Icons.Default.CheckCircle, null, tint = Red)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(notifications: Boolean, onNotifications: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text("AJUSTES", color = White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Text("Preferencias de la aplicación", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Notificaciones", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Avisos de futuras actualizaciones", color = Muted, fontSize = 10.sp)
            }
            Switch(checked = notifications, onCheckedChange = onNotifications)
        }
        Spacer(Modifier.height(12.dp))
        InfoCard("Motor de conexión", "OpenVPN · pendiente", Icons.Default.VpnLock, "Se integrará antes de habilitar conexiones")
        Spacer(Modifier.height(12.dp))
        InfoCard("Filtro DNS", "Pendiente", Icons.Default.Shield, "No bloquea anuncios en esta versión")
        Spacer(Modifier.height(12.dp))
        InfoCard("Privacidad", "VPN gratuita en desarrollo", Icons.Default.Shield, "Los servidores públicos pueden registrar actividad")
        Spacer(Modifier.height(20.dp))
        Text("JERSSON VPN · 0.3.0", color = Muted, fontSize = 10.sp)
        Text("Esta aplicación todavía no protege tu conexión. No la uses como VPN hasta completar las pruebas.", color = Color(0xFFFFC66D), fontSize = 11.sp)
    }
}
