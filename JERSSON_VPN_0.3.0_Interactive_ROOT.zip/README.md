# JERSSON VPN — versión 0.3.0

Aplicación Android en Kotlin y Jetpack Compose, con identidad visual negro/rojo.

## Estado de esta versión
- Navegación inferior entre Inicio, Servidores y Ajustes.
- Selección local de una ubicación del catálogo (no representa una conexión).
- Botón de conexión que informa claramente que el motor VPN aún no está integrado.
- Ajuste local de notificaciones de la interfaz.
- La aplicación NO establece túneles VPN ni protege el tráfico en esta versión.

## Próxima etapa técnica
Integrar una implementación OpenVPN compatible con Android, sus permisos/servicio, perfiles de servidores públicos verificados y pruebas de fugas DNS/IP. No se deben mostrar estados de conexión o protección hasta verificar un túnel real.

## Compilación
El workflow de GitHub Actions compila `app/build/outputs/apk/debug/app-debug.apk`.
